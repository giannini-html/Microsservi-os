package com.github.acnaweb.study_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
